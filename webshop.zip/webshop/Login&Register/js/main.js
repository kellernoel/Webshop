(function($) {

    $(".toggle-password").click(function() {

        $(this).toggleClass("zmdi-eye zmdi-eye-off");
        var input = $($(this).attr("toggle"));
        if (input.attr("type") == "password") {
          input.attr("type", "text");
        } else {
          input.attr("type", "password");
        }
      });

$(document).ready(function(){


  $("a").mouseenter(function () {

    $(this).css("color", "white");

});



$("a").mouseleave(function () {

    $(this).css("color", "black");

});

      /*$("a").addClass("colored");

      // Aufgabe 4
      $("a").mouseover(function(){
        $(this).addClass("mouseon");
      });
      // Aufgabe 5
      $("a").mouseout(function(){
        $(this).removeClass("mouseon");
      });
*/
    });
})(jQuery);
