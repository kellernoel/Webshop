/*!
* Start Bootstrap - Shop Homepage v5.0.5 (https://startbootstrap.com/template/shop-homepage)
* Copyright 2013-2022 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-shop-homepage/blob/master/LICENSE)
*/
// This file is intentionally blank
// Use this file to add JavaScript to your project

$(document).ready(function(){

    const addcart = document.getElementById("addtocart");
    const addcart2 = document.getElementById("addtocart2");

    var i = 0;
    var e = 0;


    $(addcart).click(function(){

        if(i < 250){
            document.getElementById("number").innerHTML = ++i;
        }

    });

    /*$(function WriteFile(){
    var fileWriter = new FileWriter("C:\Users\noel_\BBBaden\Nedim.Kaba - WebShop\startbootstrap-shop-homepage-gh-pages\startbootstrap-shop-homepage-gh-pages\filewriter.txt");
    
    fileWriter.open(); 
    fileWriter.writeLine("Another line"); 
    fileWriter.close();

    });

    */



});
